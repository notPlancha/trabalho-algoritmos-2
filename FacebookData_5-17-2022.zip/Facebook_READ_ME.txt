﻿# Facebook social data: 
# users – x , y - and number of interactions from x to y.
# Artificial data
# Can be used to build a graph and test several algorithms.

